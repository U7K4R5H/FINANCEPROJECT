package model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Set;


/**
 * The persistent class for the ORDER_TABLE database table.
 * 
 */
@Entity
@Table(name="ORDER_TABLE")
@NamedQuery(name="OrderTable.findAll", query="SELECT o FROM OrderTable o")
public class OrderTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ORD_ID")
	private long ordId;

	private String emi;

	@Column(name="EMI_PER_MONTH")
	private BigDecimal emiPerMonth;

	private BigDecimal quantity;

	@Column(name="REMAINING_AMOUNT")
	private BigDecimal remainingAmount;

	@Column(name="TOTAL_COST")
	private BigDecimal totalCost;

	//bi-directional many-to-one association to CardTable
	@ManyToOne
	@JoinColumn(name="CARD_NO")
	private CardTable cardTable;

	//bi-directional many-to-one association to ProductTable
	@ManyToOne
	@JoinColumn(name="PRODUCT_ID")
	private ProductTable productTable;

	//bi-directional many-to-one association to TransactionTable
	@OneToMany(mappedBy="orderTable", fetch=FetchType.EAGER)
	private Set<TransactionTable> transactionTables;

	public OrderTable() {
	}

	public long getOrdId() {
		return this.ordId;
	}

	public void setOrdId(long ordId) {
		this.ordId = ordId;
	}

	public String getEmi() {
		return this.emi;
	}

	public void setEmi(String emi) {
		this.emi = emi;
	}

	public BigDecimal getEmiPerMonth() {
		return this.emiPerMonth;
	}

	public void setEmiPerMonth(BigDecimal emiPerMonth) {
		this.emiPerMonth = emiPerMonth;
	}

	public BigDecimal getQuantity() {
		return this.quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getRemainingAmount() {
		return this.remainingAmount;
	}

	public void setRemainingAmount(BigDecimal remainingAmount) {
		this.remainingAmount = remainingAmount;
	}

	public BigDecimal getTotalCost() {
		return this.totalCost;
	}

	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}

	public CardTable getCardTable() {
		return this.cardTable;
	}

	public void setCardTable(CardTable cardTable) {
		this.cardTable = cardTable;
	}

	public ProductTable getProductTable() {
		return this.productTable;
	}

	public void setProductTable(ProductTable productTable) {
		this.productTable = productTable;
	}

	public Set<TransactionTable> getTransactionTables() {
		return this.transactionTables;
	}

	public void setTransactionTables(Set<TransactionTable> transactionTables) {
		this.transactionTables = transactionTables;
	}

	public TransactionTable addTransactionTable(TransactionTable transactionTable) {
		getTransactionTables().add(transactionTable);
		transactionTable.setOrderTable(this);

		return transactionTable;
	}

	public TransactionTable removeTransactionTable(TransactionTable transactionTable) {
		getTransactionTables().remove(transactionTable);
		transactionTable.setOrderTable(null);

		return transactionTable;
	}

}