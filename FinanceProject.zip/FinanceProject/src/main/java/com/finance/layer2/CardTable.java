package com.finance.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;


/**
 * The persistent class for the CARD_TABLE database table.
 * 
 */
@Entity
@Table(name="CARD_TABLE")
@NamedQuery(name="CardTable.findAll", query="SELECT c FROM CardTable c")
public class CardTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CARD_NO")
	private long cardNo;

	@Column(name="CARD_LIMIT")
	private BigDecimal cardLimit;

	@Column(name="CUST_NAME")
	private String custName;

	@Temporal(TemporalType.DATE)
	@Column(name="END_DATE")
	private Date endDate;

	@Temporal(TemporalType.DATE)
	@Column(name="START_DATE")
	private Date startDate;

	//bi-directional many-to-one association to BankTable
	@ManyToOne
	@JoinColumn(name="ACCOUNT_NO")
	private BankTable bankTable;

	//bi-directional many-to-one association to OrderTable
	@OneToMany(mappedBy="cardTable", fetch=FetchType.EAGER)
	private Set<OrderTable> orderTables;

	public CardTable() {
	}

	public long getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(long cardNo) {
		this.cardNo = cardNo;
	}

	public BigDecimal getCardLimit() {
		return this.cardLimit;
	}

	public void setCardLimit(BigDecimal cardLimit) {
		this.cardLimit = cardLimit;
	}

	public String getCustName() {
		return this.custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public BankTable getBankTable() {
		return this.bankTable;
	}

	public void setBankTable(BankTable bankTable) {
		this.bankTable = bankTable;
	}

	public Set<OrderTable> getOrderTables() {
		return this.orderTables;
	}

	public void setOrderTables(Set<OrderTable> orderTables) {
		this.orderTables = orderTables;
	}

	public OrderTable addOrderTable(OrderTable orderTable) {
		getOrderTables().add(orderTable);
		orderTable.setCardTable(this);

		return orderTable;
	}

	public OrderTable removeOrderTable(OrderTable orderTable) {
		getOrderTables().remove(orderTable);
		orderTable.setCardTable(null);

		return orderTable;
	}

	public void add(CardTable cardTable) {
		// TODO Auto-generated method stub
		
	}

	public void remove(CardTable cardTable) {
		// TODO Auto-generated method stub
		
	}

}