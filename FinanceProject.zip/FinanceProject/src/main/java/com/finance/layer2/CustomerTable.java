package com.finance.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the CUSTOMER_TABLE database table.
 * 
 */
@Entity
@Table(name="CUSTOMER_TABLE")
@NamedQuery(name="CustomerTable.findAll", query="SELECT c FROM CustomerTable c")
public class CustomerTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ADHAR_CARD")
	private long adharCard;

	private String address;

	@Column(name="CARD_FEE")
	private String cardFee;

	@Column(name="CARD_TYPE")
	private String cardType;

	@Column(name="CONFIRM_PASSWORD")
	private String confirmPassword;

	@Temporal(TemporalType.DATE)
	private Date dob;

	@Column(name="EMAIL_ID")
	private String emailId;

	private String name;

	private String password;

	@Column(name="PHONE_NO")
	private BigDecimal phoneNo;

	@Temporal(TemporalType.DATE)
	@Column(name="REGISTRATION_DATE")
	private Date registrationDate;

	private String username;

	//bi-directional one-to-one association to BankTable
	@OneToOne
	@JoinColumn(name="ADHAR_CARD", referencedColumnName="ADHAR_CARD")
	private BankTable bankTable;

	public CustomerTable() {
	}

	public long getAdharCard() {
		return this.adharCard;
	}

	public void setAdharCard(long adharCard) {
		this.adharCard = adharCard;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCardFee() {
		return this.cardFee;
	}

	public void setCardFee(String cardFee) {
		this.cardFee = cardFee;
	}

	public String getCardType() {
		return this.cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getConfirmPassword() {
		return this.confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public Date getDob() {
		return this.dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmailId() {
		return this.emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getPhoneNo() {
		return this.phoneNo;
	}

	public void setPhoneNo(BigDecimal phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Date getRegistrationDate() {
		return this.registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public BankTable getBankTable() {
		return this.bankTable;
	}

	public void setBankTable(BankTable bankTable) {
		this.bankTable = bankTable;
	}

}