package com.finance.layer2;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;


/**
 * The persistent class for the BANK_TABLE database table.
 * 
 */
@Entity
@Table(name="BANK_TABLE")
@NamedQuery(name="BankTable.findAll", query="SELECT b FROM BankTable b")
public class BankTable implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ACCOUNT_NO")
	private long accountNo;

	@Column(name="BANK_TYPE")
	private String bankType;

	@Column(name="IFSC_CODE")
	private String ifscCode;

	//bi-directional many-to-one association to CardTable
	@OneToOne(mappedBy="bankTable", fetch=FetchType.EAGER)
	
	private CardTable cardTables;

	//bi-directional one-to-one association to CustomerTable
	@OneToOne(mappedBy="bankTable")
	private CustomerTable customerTable;

	public BankTable() {
	}

	public long getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getBankType() {
		return this.bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getIfscCode() {
		return this.ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public CardTable getCardTables() {
		return this.cardTables;
	}

	public void setCardTables(CardTable cardTables) {
		this.cardTables = cardTables;
	}

	public CardTable addCardTable(CardTable cardTable) {
		getCardTables().add(cardTable);
		cardTable.setBankTable(this);

		return cardTable;
	}

	public CardTable removeCardTable(CardTable cardTable) {
		getCardTables().remove(cardTable);
		cardTable.setBankTable(null);

		return cardTable;
	}

	public CustomerTable getCustomerTable() {
		return this.customerTable;
	}

	public void setCustomerTable(CustomerTable customerTable) {
		this.customerTable = customerTable;
	}

}